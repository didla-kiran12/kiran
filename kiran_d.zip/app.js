const memoryFeed = document.getElementById('memory-feed');
const uploadSection = document.getElementById('upload-section');
const uploadForm = document.getElementById('upload-form');

function showUploadForm() {
  uploadSection.classList.toggle('hidden');
}

uploadForm.addEventListener('submit', function (e) {
  e.preventDefault();

  const title = uploadForm.querySelector('input[type="text"]').value;
  const desc = uploadForm.querySelector('textarea').value;

  const card = document.createElement('div');
  card.className = 'memory-card';
  card.innerHTML = `
    <h3>${title}</h3>
    <p>${desc}</p>
    <p><strong>Uploaded just now</strong></p>
  `;
  memoryFeed.prepend(card);
  uploadForm.reset();
  uploadSection.classList.add('hidden');
});
